



Dear Data I/O Customer:

The EZ-ABEL product is an excellent tool for the design of simple to 
medium complexity Programmable Logic Devices.  However, if you wish 
to design with more complex devices such as Complex PLDs (CPLDs) or 
Field Programmable Gate Arrays (FPGAs), Data I/O offers more advanced 
tools. For more information on advanced design tools for Programmable
Devices, contact your local Data I/O representative.

Data I/O Sales Offices:

In U.S. and Canada Call: 1 800 332-8246

Germany           Brazil          Korea            South Africa
Data I/O GmbH     Sistronics      Myoung Corp      Electronic Bldg
089 858580        011 247-5588    (02) 784-9942    012 8037680

Japan             Denmark         Malaysia         Spain
Data I/O Japan    Ambitron        Mecomb           Unitronics
81-3-3432-6991    42 458320       03-774-3422      (1) 542-5204

United Kingdom    Finland         Mexico           Sweden
Data I/O Ltd.     Ambitron        Christensen      Teleinstrument
0734-440011       90-502-3300     91 5 6832857     08-38 03 70

Argentina         France          Netherlands      Switzerland
Reycom            MB Electronique Simac            Instrumatic
(01) 45 6459      39 56 81 31     040-582911       01 7231410	

Australia         Greece          New Zealand      Taiwan
Elmeasco          Eltronics       Enertec Svcs     ILAC Company
02 736 2888       01 724 9511     09 479 2377      02 6522255

Austria           Hong Kong       Norway           Thailand
Rekirsch Elektron Euro Tech       Teleinstruments  Dynamic Supply
43 222 253626     814 0311        02 901190        02-3925313

Belgium           India           Philippines      Turkey
Simac Electronics Transmarketing  TCT Inc          EMPA
02 252 3690       022 492 6044    8193141          1 599 30 50

Israel            Ireland         Italy            Singapore
Telsys Ltd        Atron           Sistrel SpA      Mecomb 
03 492001         01-2953000      02-6181893       4698833

People's Republic of China
Dorado Int'l
770 2021

